# ScholarAthlete OLED

A mobile-first De La Salle High School schedule and athletics web app.

## Run it
- Open `index.html` in a modern browser, or
- Upload this folder's `index.html` to a GitHub repository and enable **Settings → Pages** to publish it as a website.

## Included
- DLS class roster and selectable A-Day / B-Day / special bell schedules
- Period 2 semester switch (First Aid / Study Hall)
- Live class status and merged school/sports timeline
- Add, filter, and delete athletics events
- Sports-event data saved in the current browser using local storage
- Notification toggle and audio chime (browser permissions may be required)

## Notes
- Tailwind CSS, Lucide icons, and Google Fonts load from external CDNs, so an internet connection is needed for full styling/icons.
- Calendar import controls in this version are demonstration placeholders; they do not fully parse or synchronize TeamSnap/BYGA `.ics` feeds.
- Data is stored locally in the browser on that device; it does not sync between devices.
